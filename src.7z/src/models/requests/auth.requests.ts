export interface RefreshReqBody {
    refreshToken: string;
}
